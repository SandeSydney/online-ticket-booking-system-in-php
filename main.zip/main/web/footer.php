<footer class="footer">
  <div class="w3l-footer-bottom">
    <div class="container-fluid">
      <div class="col-md-4 w3-footer-logo">
        <h2><a href="index.html">Online Ticket Booking</a></h2>
      </div>
      <div class="col-md-7 agileits-footer-class">
        <p>A Project on Online Ticket Booking System. Designed and Developed By Parag Saxena &amp; Priya Soni</p>
      </div>
      <div class="clearfix"> </div>
    </div>
  </div>
  </footer>
